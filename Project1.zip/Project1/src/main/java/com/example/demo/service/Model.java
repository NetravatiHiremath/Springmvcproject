package com.example.demo.service;

import java.util.List;


import com.example.demo.entity.Employee;

public interface Model 
{
 Employee add(Employee e);
 
 List<Employee> getall();
 
 Employee getById(long id);
 
 Employee update(long id,Employee e);
 
 void delete(long id);


}
