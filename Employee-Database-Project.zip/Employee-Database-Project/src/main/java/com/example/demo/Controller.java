package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.http.HttpSession;

@org.springframework.stereotype.Controller
public class Controller 
{
	@Autowired
	EmployeeRepo repo;
	
	@RequestMapping("/add")
    String display()
    {
    	return "display.jsp";
    }
	
	@RequestMapping("/save")
	String addEmployee(Employee e)
	{
		repo.save(e);
		return "display.jsp";
	}
	
	@RequestMapping("/find")
	String findEmployee()
	{
		return "find.jsp";
	}

	@RequestMapping("/detailsById")
	String detailsById( HttpSession h1,Integer id )
	{
		Employee e= repo.findById(id).orElse(null);
		if(e!=null)
		{
		h1.setAttribute("id", e.getId());
		h1.setAttribute("name", e.getName());
		h1.setAttribute("email", e.getEmail());
		h1.setAttribute("phno", e.getPhno());
		h1.setAttribute("designation", e.getDesignation());
		h1.setAttribute("salary", e.getSalary());
		return "view.jsp";
		}
		else
		{
			h1.setAttribute("message", "Invalid Id..!") ;
			return "details.jsp";
		}
	}
	
	@RequestMapping("/delete")
	String deleteEmployee()
	{
		return "delete.jsp";
	}

	@RequestMapping("/deleteById")
	String deleteById(Integer id,HttpSession h1)
	{
		Employee e= repo.findById(id).orElse(null);
		if(e!=null)
		{
			h1.setAttribute("message", "Employee with id : "+id+" got deleted") ;
			repo.deleteById(id);
		}
		else
		{
			h1.setAttribute("message", "Invalid Id..!") ; 
		}

		return "details.jsp";
	}
	
	

	
}
