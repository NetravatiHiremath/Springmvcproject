package com.example.demo.model;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.example.demo.dto.MvcDto;

@Component
public class MvcModel {

	public MvcDto consume( Long id) {
		RestTemplate rest = new RestTemplate();
		System.out.println("hi");
		MvcDto get = rest.getForObject("http://localhost:8080/gett/"+id, MvcDto.class);
		return get;
	}
}
