package com.example.demo.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class MvcDto 
{
  private long id;
  private String name;
  private long phno;
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public long getPhno() {
	return phno;
}
public void setPhno(long phno) {
	this.phno = phno;
}
@Override
public String toString() {
	return "MvcDto [id=" + id + ", name=" + name + ", phno=" + phno + "]";
}
  
  
}
