package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpSession;

@Controller
public class SController
{
	@Autowired
	StudentRepo repo;

	@RequestMapping("/add")
	String display()
	{

		return "details.jsp";
	}

	@RequestMapping("/save")
	String saveStudent(Student s)
	{
		repo.save(s);
		return "details.jsp";
	}
	

	@RequestMapping("/detailsById")
	String detailsById( HttpSession h1,Integer sid )
	{
		Student s= repo.findById(sid).orElse(null);
		h1.setAttribute("id", s.getSid());
		h1.setAttribute("name", s.getName());
		h1.setAttribute("phno", s.getPhno());
		h1.setAttribute("email", s.getEmail());
		return "view.jsp";
	}
	
	

	@RequestMapping("/deleteById")
	String deleteById(Integer sid,HttpSession h1)
	{
		Student s= repo.findById(sid).orElse(null);
		if(s!=null)
		{
			h1.setAttribute("message", "student with id"+sid+"got deleted") ;
			repo.deleteById(sid);
		}
		else
		{
			h1.setAttribute("message", "Invalid Id..!") ; 
		}

		return "delete.jsp";
	}

	@RequestMapping("/ByEmail")
	@ResponseBody
	List<Student> findByEmail(String email) 
	{
		return repo.findByEmail(email) ; // in browser we'll get a jason data and it is converted by jackson
	}

	
	@RequestMapping("/Byphno")
	@ResponseBody
	List<Student> orderByphno()
	{
      return repo.orderByphno();
	}
	
	@RequestMapping("/ByName")
	@ResponseBody
	List<Student> findByName(String name)
	{
		return repo.findByName(name);
	}
}
